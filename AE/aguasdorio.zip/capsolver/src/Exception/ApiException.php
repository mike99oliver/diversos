<?php

namespace CapSolver\Exception;

use Exception;

class ApiException extends Exception
{



}
