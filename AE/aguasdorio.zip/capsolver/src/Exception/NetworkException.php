<?php

namespace CapSolver\Exception;

use Exception;

class NetworkException extends Exception
{

}
