<?php

namespace CapSolver\Exception;

use Exception;

class TimeoutException extends Exception
{

}
