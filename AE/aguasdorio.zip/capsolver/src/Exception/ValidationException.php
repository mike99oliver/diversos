<?php

namespace CapSolver\Exception;

use Exception;

class ValidationException extends Exception
{

}
