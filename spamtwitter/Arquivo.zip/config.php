<?php
$HOST = 'localhost';
$USER = 'root';
$PASS = '';
$MYDB = 'spamtwitter';

$sql = new mysqli($HOST,$USER,$PASS,$MYDB);